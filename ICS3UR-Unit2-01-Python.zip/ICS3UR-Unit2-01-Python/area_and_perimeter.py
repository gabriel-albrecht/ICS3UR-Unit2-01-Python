#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This program calculates the area and perimeter of a circle with a 12m radius

import math


def main():
    print("If a circle has a radius of 12 meters:")
    print("")
    print("Area is {}m^2".format(math.pi*12**2))
    print("Perimeter is {}m".format(2*math.pi*12))


if __name__ == "__main__":
    main()
